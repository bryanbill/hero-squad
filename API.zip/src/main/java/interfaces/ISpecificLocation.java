package interfaces;

import models.SpecificLocation;

import java.util.List;

public interface ISpecificLocation {
    //CREATE
    void add(SpecificLocation specificLocation);

    //READ
    List<SpecificLocation> getAll();
    List<SpecificLocation> getAllByLocation(int location_id);
    SpecificLocation findASpecificLocationByName(String name);
    SpecificLocation findASpecificLocationById(int id);


    //UPDATE
    void update(SpecificLocation specificLocation);

    //DELETE
    void deleteById(int id);

    void clearAll();
}
