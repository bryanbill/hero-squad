package interfaces;

import models.Doctor;
import models.Hospital;
import models.Payment;

import java.util.List;

public interface IDoctor {

    //CREATE
    void add(Doctor doctor);
    void addDoctorToHospital(int doctor_id,int hospital_id);
    void addPaymentToDoctor(int doctor_id,int payment_id);

    //READ
    List<Doctor> getAll();
    List<Doctor> getAllDoctorsInALocation(int location_id);
    List<Doctor> getAllDoctorsWithASpeciality(int speciality_id);
    List<Hospital> getAllHospitalsForADoctor(int doctor_id);
    List<Doctor> getAllDoctorsInHospital(int hospital_id);
    List<Payment> getAllPaymentsForADoctor(int doctor_id);
    List<Doctor> getAllDoctorsUsingAPayment(int payment_id);
    List<Doctor> getAllDoctorsBySpecialtyInLocation(int location_id, int specialty_id);
    Doctor findADoctorByName(String doc_name);
    Doctor findADoctorById(int id);
    Doctor findADoctorByLocation(int doctor_id, int location_id);
    Doctor findADoctorBySpeciality(int doctor_id, int speciality_id);
    Doctor findADoctorByRating(double rating);
    Doctor findADoctorViaHospitalById(int doctor_id,int hospital_id);
    Doctor findADoctorViaPaymentById(int doctor_id,int payment_id);


    //UPDATE
    void update(Doctor doctor);
    void updateADoctorWithNewHospital(int doctor_id,int hospital_id);
    void updateADoctorWithNewPayment(int doctor_id,int payment_id);

    //DELETE
    void deleteById(int id);
    void deleteADoctorFromHospital(int doctor_id,int hospital_id);
    void deleteAPaymentFromDoctor(int doctor_id,int payment_id);

    void clearAll();
    void clearAllDoctorsInAHospital(int hospital_id);
    void clearAPaymentFromAllDoctors(int payment_id);

}
