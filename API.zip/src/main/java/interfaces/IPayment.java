package interfaces;

import models.Payment;

import java.util.List;

public interface IPayment {
    //CREATE
    void add(Payment payment);

    //READ
    List<Payment> getAll();
    Payment findAPaymentByName(String name);
    Payment findAPaymentById(int id);

    //UPDATE
    void update(Payment payment);

    //DELETE
    void deleteById(int id);

    void clearAll();
}
