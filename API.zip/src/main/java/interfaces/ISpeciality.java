package interfaces;

import models.Specialty;

import java.util.List;

public interface ISpeciality {
    //CREATE
    void add(Specialty specialty);

    //READ
    List<Specialty> getAll();
    Specialty findASpecialtyByName(String name);
    Specialty findASpecialtyById(int id);

    //UPDATE
    void update(Specialty specialty);

    //DELETE
    void deleteById(int id);

    void clearAll();
}
