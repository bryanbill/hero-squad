package interfaces;


import models.Service;

import java.util.List;

public interface IService {
    //CREATE
    void add(Service service);

    //READ
    List<Service> getAll();
    Service findAServiceByName(String name);
    Service findAServiceById(int id);

    //UPDATE
    void update(Service service);

    //DELETE
    void deleteById(int id);

    void clearAll();
}
