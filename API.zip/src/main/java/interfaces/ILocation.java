package interfaces;

import models.Location;
import models.Service;
import models.Specialty;

import java.util.List;

public interface ILocation {
    //CREATE
    void add(Location location);
    void addServiceToLocation(int location_id,int services_id);
    void addSpecialtyToLocation(int location_id,int specialty_id);

    //READ
    List<Location> getAll();
    List<Location> getAllLocationsOfferingAService(int services_id);
    List<Service> getAllServicesInALocation(int location_id);
    List<Location> getAllLocationsWithASpecialty(int specialty_id);
    List<Specialty> getAllSpecialtiesInALocation(int location_id);
    Location findALocationByName(String name);
    Location findALocationById(int id);
    Service findAServiceViaLocationById(int location_id,int services_id);
    Specialty findASpecialtyViaLocationById(int location_id,int specialty_id);

    //UPDATE
    void update(Location location);
    void updateLocationWithNewService(int location_id,int services_id);
    void updateLocationWithNewSpecialty(int location_id,int specialty_id);

    //DELETE
    void deleteById(int id);
    void deleteServiceFromLocation(int location_id,int services_id);
    void deleteSpecialtyFromLocation(int location_id,int specialty_id);

    void clearAll();
    void clearAllServicesFromALocation(int location_id);
    void clearAllSpecialtiesFromALocation(int location_id);
}
