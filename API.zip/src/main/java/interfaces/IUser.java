package interfaces;

import models.Users;

import java.util.List;

public interface IUser {

    //CREATE
    void register(Users user);

    //VERIFY
    Users login(String email);

    //READ
    Users getUser(int id);
    List<Users> getUsersByRole(String role);
    List<Users> getAllUsers();

    //UPDATE
    boolean updateUser(Users user);

    //DELETE
    Users deleteUser(int id);
}
