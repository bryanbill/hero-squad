package interfaces;

import models.Hospital;
import models.Payment;
import models.Service;
import models.Specialty;

import java.util.List;

public interface IHospital {

    //CREATE
    void add(Hospital hospital);
    void addPaymentToHospital(int hospital_id,int payment_id);
    void addServiceToHospital(int hospital_id,int services_id);
    void addSpecialtyToHospital(int hospital_id,int specialty_id);

    //READ
    List<Hospital> getAll();
    List<Hospital> getAllHospitalsInALocation(int location_id);
    List<Hospital> getAllHospitalsInASpecificLocation(int specificlocation_id);
    List<Payment> getAllPaymentsForAHospital(int hospital_id);
    List<Hospital> getAllHospitalsUsingAPayment(int payment_id);
    List<Service> getAllServicesInAHospital(int hospital_id);
    List<Hospital> getAllHospitalsWithAService(int services_id);
    List<Specialty> getAllSpecialtiesInAHospital(int hospital_id);
    List<Hospital> getAllHospitalsWithASpecialty(int speciality_id);
    Hospital findAHospitalByName(String name);
    Hospital findAHospitalById(int id);
    Hospital findAHospitalByLocation(int hospital_id, int location_id);
    Hospital findAHospitalBySpecificLocation(int hospital_id, int specificlocation_id);
    Hospital findAHospitalByRating(double rating);
    Hospital findAHospitalByWorkingHours(String operating_hours);
    Hospital findAHospitalViaPaymentById(int hospital_id,int payment_id);
    Hospital findAHospitalViaServiceById(int hospital_id,int services_id);
    Hospital findAHospitalViaSpecialtyById(int hospital_id,int specialty_id);


    //UPDATE
    void update(Hospital hospital);
    void updateAHospitalWithNewPayment(int hospital_id,int payment_id);
    void updateHospitalWithNewService(int hospital_id,int services_id);
    void updateHospitalWithNewSpecialty(int hospital_id,int specialty_id);

    //DELETE
    void deleteById(int id);
    void deleteAPaymentFromHospital(int hospital_id,int payment_id);
    void deleteServiceFromHospital(int hospital_id,int services_id);
    void deleteSpecialtyFromHospital(int hospital_id,int specialty_id);

    void clearAll();
    void clearAPaymentFromAllHospitals(int payment_id);
    void clearServiceFromAllHospitals(int services_id);
    void clearSpecialtyFromAllHospitals(int specialty_id);

    List<Hospital> getAllHospitalsInSpecificLocationUsingAPayment(int payment_id, int specificlocation_id);

    List<Hospital> getAllHospitalsInLocationUsingAPayment(int payment_id, int location_id);

    List<Hospital> getAllHospitalsByServiceInSpecificLocation(int specificlocation_id, int services_id);
    List<Hospital> getAllHospitalsByServiceInLocation(int location_id, int services_id);
}
