package dao;


import interfaces.ISpecificLocation;
import models.SpecificLocation;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class SpecificLocationDao implements ISpecificLocation {

    private final Sql2o sql2o;

    public SpecificLocationDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(SpecificLocation specificLocation) {
        String sql = "INSERT INTO specificlocations (name,location_id) VALUES (:name,:location_id);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(specificLocation)
                    .executeUpdate()
                    .getKey();
            specificLocation.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public List<SpecificLocation> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specificlocations;")
                    .executeAndFetch(SpecificLocation.class);
        }
    }

    @Override
    public List<SpecificLocation> getAllByLocation(int location_id) {
        try (Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specificlocations WHERE location_id = :location_id;")
                    .addParameter("location_id", location_id)
                    .executeAndFetch(SpecificLocation.class);
        }
    }

    @Override
    public SpecificLocation findASpecificLocationByName(String name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specificlocations WHERE name = :name;")
                    .addParameter("name",name)
                    .executeAndFetchFirst(SpecificLocation.class);
        }
    }

    @Override
    public SpecificLocation findASpecificLocationById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specificlocations WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(SpecificLocation.class);
        }
    }

    @Override
    public void update(SpecificLocation specificLocation) {
        String sql = "UPDATE specificlocations SET (name,location_id) = (:name,:location_id) WHERE id =:id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(specificLocation)
                    .executeUpdate();
        }

    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM specificlocations WHERE id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM specificlocations;")
                    .executeUpdate();
        }
    }
}
