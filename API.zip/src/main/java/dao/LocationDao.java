package dao;

import interfaces.ILocation;
import models.Location;
import models.Service;
import models.Specialty;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class LocationDao implements ILocation {
    private final Sql2o sql2o;

    public LocationDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(Location location) {
        String sql = "INSERT INTO locations (name) VALUES (:name);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(location)
                    .executeUpdate()
                    .getKey();
            location.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public void addServiceToLocation(int location_id, int services_id) {
        String sql ="INSERT INTO locations.services (location_id,services_id) VALUES (:location_id,:services_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("location_id",location_id)
                    .addParameter("services_id",services_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public void addSpecialtyToLocation(int location_id, int specialty_id) {
        String sql ="INSERT INTO locations.specialties (location_id,specialty_id) VALUES (:location_id,:specialty_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("location_id",location_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public List<Location> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM locations;")
                    .executeAndFetch(Location.class);
        }
    }

    @Override
    public List<Location> getAllLocationsOfferingAService(int services_id) {
        String sql = "SELECT locations.* FROM locations JOIN locations.services ON locations.services.location_id = locations.id WHERE locations.services.id = :services_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("services_id",services_id)
                    .executeAndFetch(Location.class);
        }
    }

    @Override
    public List<Service> getAllServicesInALocation(int location_id) {
        String sql = "SELECT public.services.* FROM services JOIN locations.services ON locations.services.services_id = public.services.id WHERE locations.services.location_id = :location_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .executeAndFetch(Service.class);
        }
    }

    @Override
    public List<Location> getAllLocationsWithASpecialty(int specialty_id) {
        String sql = "SELECT locations.* FROM locations JOIN locations.specialties ON locations.specialties.location_id = locations.id WHERE locations.specialties.id = :specialty_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("specialty_id",specialty_id)
                    .executeAndFetch(Location.class);
        }
    }

    @Override
    public List<Specialty> getAllSpecialtiesInALocation(int location_id) {
        String sql = "SELECT public.specialties.* FROM specialties JOIN locations.specialties ON locations.specialties.specialty_id = public.specialties.id WHERE locations.specialties.location_id = :location_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .executeAndFetch(Specialty.class);
        }
    }

    @Override
    public Location findALocationByName(String name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM locations WHERE name = :name;")
                    .addParameter("name",name)
                    .executeAndFetchFirst(Location.class);
        }
    }

    @Override
    public Location findALocationById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM locations WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(Location.class);
        }
    }

    @Override
    public Service findAServiceViaLocationById(int location_id, int services_id) {
        String sql = "SELECT public.services.* FROM services JOIN locations.services ON locations.services.services_id = public.services.id WHERE locations.services.location_id = :location_id AND public.services.id = :services_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .addParameter("service_id",services_id)
                    .executeAndFetchFirst(Service.class);
        }
    }

    @Override
    public Specialty findASpecialtyViaLocationById(int location_id, int specialty_id) {
        String sql = "SELECT public.specialties.* FROM specialties JOIN locations.specialties ON locations.specialties.specialty_id = public.specialties.id WHERE locations.specialties.location_id = :location_id AND public.specialties.id = :specialty_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeAndFetchFirst(Specialty.class);
        }
    }

    @Override
    public void update(Location location) {
        String sql = "UPDATE locations SET (name) = (:name) WHERE id = :id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(location)
                    .executeUpdate();
        }
    }

    @Override
    public void updateLocationWithNewService(int location_id, int services_id) {
        String sql ="UPDATE locations.services SET (location_id,services_id) = (:location_id,:services_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .addParameter("services_id",services_id)
                    .executeUpdate();
        }
    }

    @Override
    public void updateLocationWithNewSpecialty(int location_id, int specialty_id) {
        String sql ="UPDATE locations.specialties SET (location_id,specialty_id) = (:location_id,:specialty_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM locations WHERE id = :id; DELETE FROM locations.services WHERE location_id = :id; DELETE FROM location.specialties WHERE location_id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteServiceFromLocation(int location_id, int services_id) {
        String sql ="DELETE FROM locations.services WHERE location_id = :location_id AND services_id = :services_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .addParameter("services_id",services_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteSpecialtyFromLocation(int location_id, int specialty_id) {
        String sql ="DELETE FROM locations.specialties WHERE location_id = :location_id AND specialty_id = :specialty_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM locations; TRUNCATE TABLE locations.specialties; TRUNCATE TABLE locations.services;")
                    .executeUpdate();
        }
    }

    @Override
    public void clearAllServicesFromALocation(int location_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM locations.services WHERE location_id = :location_id;")
                    .addParameter("location_id",location_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAllSpecialtiesFromALocation(int location_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM locations.specialties WHERE location_id = :location_id;")
                    .addParameter("location_id",location_id)
                    .executeUpdate();
        }
    }
}
