package dao;

import interfaces.IHospital;
import models.*;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class HospitalDao implements IHospital {

    private final Sql2o sql2o;

    public HospitalDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(Hospital hospital) {
        String sql = "INSERT INTO hospitals (name, email, phone_number, specificlocation_id, location_id, rating, operating_hours, image_url, address) VALUES (:name, :email, :phone_number, :specificlocation_id, :location_id, :rating, :operating_hours, :image_url, :address);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(hospital)
                    .executeUpdate()
                    .getKey();
            hospital.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public void addPaymentToHospital(int hospital_id, int payment_id) {
        String sql ="INSERT INTO hospitals.payments (hospital_id,payment_id) VALUES (:hospital_id,:payment_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("payment_id",payment_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public void addServiceToHospital(int hospital_id, int services_id) {
        String sql ="INSERT INTO hospitals.services (hospital_id,services_id) VALUES (:hospital_id,:services_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("services_id",services_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public void addSpecialtyToHospital(int hospital_id, int specialty_id) {
        String sql ="INSERT INTO hospitals.specialties (hospital_id,specialty_id) VALUES (:hospital_id,:specialty_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public List<Hospital> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM hospitals;")
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsInALocation(int location_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN locations ON locations.id = hospitals.location_id WHERE locations.id = :location_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsInASpecificLocation(int specificlocation_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN specificlocations ON specificlocations.id = hospitals.specificlocation_id WHERE specificlocations.id = :specificlocation_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("specificlocation_id",specificlocation_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Payment> getAllPaymentsForAHospital(int hospital_id) {
        String sql ="SELECT public.payments.* FROM payments JOIN hospitals.payments ON hospitals.payments.payment_id = public.payments.id WHERE hospitals.payments.hospital_id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .executeAndFetch(Payment.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsUsingAPayment(int payment_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.payments ON hospitals.payments.hospital_id = hospitals.id WHERE hospitals.payments.payment_id = :payment_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("payment_id",payment_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Service> getAllServicesInAHospital(int hospital_id) {
        String sql ="SELECT public.services.* FROM services JOIN hospitals.services ON hospitals.services.services_id = public.services.id WHERE hospitals.services.hospital_id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .executeAndFetch(Service.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsWithAService(int services_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.services ON hospitals.services.hospital_id = hospitals.id WHERE hospitals.services.services_id = :services_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("services_id",services_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Specialty> getAllSpecialtiesInAHospital(int hospital_id) {
        String sql ="SELECT public.specialties.* FROM specialties JOIN hospitals.specialties ON hospitals.specialties.specialty_id = public.specialties.id WHERE hospitals.specialties.hospital_id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .executeAndFetch(Specialty.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsWithASpecialty(int speciality_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.specialties ON hospitals.specialties.hospital_id = hospitals.id WHERE hospitals.specialties.specialty_id = :specialty_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("specialty_id",speciality_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsInSpecificLocationUsingAPayment(int payment_id, int specificlocation_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.payments on public.hospitals.id = hospitals.payments.hospital_id WHERE payment_id = :payment_id AND specificlocation_id = :specificlocation_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("payment_id",payment_id)
                    .addParameter("specificlocation_id",specificlocation_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsInLocationUsingAPayment(int payment_id, int location_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.payments on public.hospitals.id = hospitals.payments.hospital_id WHERE payment_id = :payment_id AND location_id = :location_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("payment_id",payment_id)
                    .addParameter("location_id",location_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsByServiceInSpecificLocation(int specificlocation_id, int services_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.services on public.hospitals.id = hospitals.services.hospital_id WHERE services_id = :services_id AND specificlocation_id = :specificlocation_id;";
        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("services_id", services_id)
                    .addParameter("specificlocation_id", specificlocation_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsByServiceInLocation(int location_id, int services_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.services on public.hospitals.id = hospitals.services.hospital_id WHERE services_id = :services_id AND location_id = :location_id;";
        try (Connection con = sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("services_id", services_id)
                    .addParameter("location_id", location_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalByName(String name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM hospitals WHERE name = :name;")
                    .addParameter("name",name)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM hospitals WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalByLocation(int hospital_id, int location_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN locations ON locations.id = hospitals.location_id WHERE locations.id = :location_id AND hospitals.id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("location_id",location_id)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalBySpecificLocation(int hospital_id, int specificlocation_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN specificlocations ON specificlocations.id = hospitals.specificlocation_id WHERE specificlocations.id = :specificlocation_id AND hospitals.id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("specificlocation_id",specificlocation_id)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalByRating(double rating) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM hospitals WHERE rating = :rating;")
                    .addParameter("rating",rating)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalByWorkingHours(String operating_hours) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM hospitals WHERE operating_hours = :operating_hours;")
                    .addParameter("operating_hours",operating_hours)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalViaPaymentById(int hospital_id, int payment_id) {
        String sql = "SELECT public.hospitals.* FROM hospitals JOIN hospitals.payments ON hospitals.payments.hospital_id = public.hospitals.id WHERE hospitals.payments.payment_id = :payment_id AND public.hospitals.id = :hospital_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("payment_id",payment_id)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalViaServiceById(int hospital_id, int services_id) {
        String sql = "SELECT public.hospitals.* FROM hospitals JOIN hospitals.services ON hospitals.services.hospital_id = public.hospitals.id WHERE hospitals.services.services_id = :services_id AND public.hospitals.id = :hospital_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("services_id",services_id)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public Hospital findAHospitalViaSpecialtyById(int hospital_id, int specialty_id) {
        String sql = "SELECT public.hospitals.* FROM hospitals JOIN hospitals.specialties ON hospitals.specialties.hospital_id = public.hospitals.id WHERE hospitals.specialties.specialty_id = :specialty_id AND public.hospitals.id = :hospital_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeAndFetchFirst(Hospital.class);
        }
    }

    @Override
    public void update(Hospital hospital) {
        String sql = "UPDATE hospitals SET (name, email, phone_number, specificlocation_id, location_id, rating, operating_hours, image_url, address) = (:name, :email, :phone_number, :specificlocation_id, :location_id, :rating, :operating_hours, :image_url, :address) WHERE id = :id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(hospital)
                    .executeUpdate();
        }
    }

    @Override
    public void updateAHospitalWithNewPayment(int hospital_id, int payment_id) {
        String sql ="UPDATE hospitals.payments SET (hospital_id,payment_id) = (:hospital_id,:payment_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("payment_id",payment_id)
                    .executeUpdate();
        }
    }

    @Override
    public void updateHospitalWithNewService(int hospital_id, int services_id) {
        String sql ="UPDATE hospitals.services SET (hospital_id,services_id) = (:hospital_id,:services_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("services_id",services_id)
                    .executeUpdate();
        }
    }

    @Override
    public void updateHospitalWithNewSpecialty(int hospital_id, int specialty_id) {
        String sql ="UPDATE hospitals.specialties SET (hospital_id,specialty_id) = (:hospital_id,:specialty_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM hospitals WHERE id = :id; DELETE FROM hospitals.doctors WHERE hospital_id = :id; DELETE FROM hospitals.payments WHERE hospital_id = :id; DELETE FROM hospitals.services WHERE hospital_id = :id; DELETE FROM hospitals.specialties WHERE hospital_id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteAPaymentFromHospital(int hospital_id, int payment_id) {
        String sql ="DELETE FROM hospitals.payments WHERE hospital_id = :hospital_id AND payment_id = :payment_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("payment_id",payment_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteServiceFromHospital(int hospital_id, int services_id) {
        String sql ="DELETE FROM hospitals.services WHERE hospital_id = :hospital_id AND services_id = :services_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("services_id",services_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteSpecialtyFromHospital(int hospital_id, int specialty_id) {
        String sql ="DELETE FROM hospitals.specialties WHERE hospital_id = :hospital_id AND specialty_id = :specialty_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .addParameter("specialty_id",specialty_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM hospitals; TRUNCATE TABLE hospitals.doctors; TRUNCATE TABLE hospitals.payments; TRUNCATE TABLE hospitals.services; TRUNCATE TABLE hospitals.specialties;")
                    .executeUpdate();
        }
    }

    @Override
    public void clearAPaymentFromAllHospitals(int payment_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM hospitals.payments WHERE payment_id = :payment_id;")
                    .addParameter("payment_id",payment_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearServiceFromAllHospitals(int services_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM hospitals.services WHERE services_id = :services_id;")
                    .addParameter("services_id",services_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearSpecialtyFromAllHospitals(int specialty_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM hospitals.specialties WHERE specialty_id = :specialty_id;")
                    .addParameter("specialties_id",specialty_id)
                    .executeUpdate();
        }
    }
}
