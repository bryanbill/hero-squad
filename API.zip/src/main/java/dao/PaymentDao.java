package dao;

import interfaces.IPayment;
import models.Payment;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class PaymentDao implements IPayment {

    private final Sql2o sql2o;

    public PaymentDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(Payment payment) {
        String sql = "INSERT INTO payments (name) VALUES (:name);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(payment)
                    .executeUpdate()
                    .getKey();
            payment.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public List<Payment> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM payments;")
                    .executeAndFetch(Payment.class);
        }
    }

    @Override
    public Payment findAPaymentByName(String name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM payments WHERE name = :name;")
                    .addParameter("name",name)
                    .executeAndFetchFirst(Payment.class);
        }
    }

    @Override
    public Payment findAPaymentById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM payments WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(Payment.class);
        }
    }

    @Override
    public void update(Payment payment) {
        String sql = "UPDATE payments SET (name) = (:name) WHERE id = :id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(payment)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM payments WHERE id = :id; DELETE FROM doctors.payments WHERE payment_id = :id; DELETE FROM hospitals.payments WHERE payment_id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM payments; TRUNCATE TABLE doctors.payments; TRUNCATE TABLE hospitals.payments;")
                    .executeUpdate();
        }
    }
}
