package dao;

import interfaces.IDoctor;
import models.Doctor;
import models.Hospital;
import models.Payment;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class DoctorDao implements IDoctor {

    private final Sql2o sql2o;

    public DoctorDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(Doctor doctor) {
        String sql = "INSERT INTO doctors (doc_name, qualification, email, phone_number, consultation_fee, rating, location_id, specialty_id, specialty_name, image_url) VALUES (:doc_name, :qualification, :email, :phone_number, :consultation_fee, :rating, :location_id, :specialty_id, :specialty_name, :image_url);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(doctor)
                    .executeUpdate()
                    .getKey();
            doctor.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public void addDoctorToHospital(int doctor_id, int hospital_id) {
        String sql ="INSERT INTO hospitals.doctors (doctor_id,hospital_id) VALUES (:doctor_id,:hospital_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("hospital_id",hospital_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public void addPaymentToDoctor(int doctor_id, int payment_id) {
        String sql ="INSERT INTO doctors.payments (doctor_id,payment_id) VALUES (:doctor_id,:payment_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql,true)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("payment_id",payment_id)
                    .executeUpdate()
                    .getKey();
        }
    }

    @Override
    public List<Doctor> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM doctors;")
                    .executeAndFetch(Doctor.class);
        }
    }

    @Override
    public List<Doctor> getAllDoctorsInALocation(int location_id) {
        String sql = "SELECT doctors.* FROM doctors JOIN locations ON locations.id = doctors.location_id WHERE locations.id = :location_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("location_id",location_id)
                    .executeAndFetch(Doctor.class);
        }
    }

    @Override
    public List<Doctor> getAllDoctorsWithASpeciality(int specialty_id) {
        String sql = "SELECT doctors.* FROM doctors JOIN specialties ON specialties.id = doctors.specialty_id WHERE specialties.id = :specialty_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("specialty_id",specialty_id)
                    .executeAndFetch(Doctor.class);
        }
    }

    @Override
    public List<Hospital> getAllHospitalsForADoctor(int doctor_id) {
        String sql = "SELECT hospitals.* FROM hospitals JOIN hospitals.doctors ON hospitals.doctors.hospital_id = hospitals.id WHERE hospitals.doctors.doctor_id = :doctor_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .executeAndFetch(Hospital.class);
        }
    }

    @Override
    public List<Doctor> getAllDoctorsInHospital(int hospital_id) {
        String sql = "SELECT public.doctors.* FROM doctors JOIN hospitals.doctors ON hospitals.doctors.doctor_id = public.doctors.id WHERE hospitals.doctors.hospital_id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("hospital_id",hospital_id)
                    .executeAndFetch(Doctor.class);
        }
    }

    @Override
    public List<Payment> getAllPaymentsForADoctor(int doctor_id) {
        String sql = "SELECT public.payments.* FROM payments JOIN doctors.payments ON doctors.payments.payment_id = public.payments.id WHERE doctors.payments.doctor_id = :doctor_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .executeAndFetch(Payment.class);
        }
    }

    @Override
    public List<Doctor> getAllDoctorsUsingAPayment(int payment_id) {
        String sql = "SELECT doctors.* FROM doctors JOIN doctors.payments ON doctors.payments.doctor_id = doctors.id WHERE doctors.payments.payment_id = :payment_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("payment_id",payment_id)
                    .executeAndFetch(Doctor.class);
        }
    }
    @Override
    public List<Doctor> getAllDoctorsBySpecialtyInLocation(int location_id, int specialty_id) {
        try (Connection con = sql2o.open()) {
            return con.createQuery("SELECT * FROM doctors WHERE location_id = :location_id AND specialty_id = :specialty_id ")
                    .addParameter("specialty_id", specialty_id)
                    .addParameter("location_id", location_id)
                    .executeAndFetch(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorByName(String doc_name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM doctors WHERE doc_name = :doc_name;")
                    .addParameter("doc_name",doc_name)
                    .executeAndFetchFirst(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM doctors WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorByLocation(int doctor_id, int location_id) {
        String sql = "SELECT doctors.* FROM doctors JOIN locations ON locations.id = doctors.location_id WHERE locations.id = :location_id AND doctors.id = :doctor_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("location_id",location_id)
                    .executeAndFetchFirst(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorBySpeciality(int doctor_id, int specialty_id) {
        String sql = "SELECT doctors.* FROM doctors JOIN specialties ON specialties.id = doctors.specialty_id WHERE specialties.id = :specialty_id AND doctors.id = :doctor_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("doctor_id", doctor_id)
                    .addParameter("specialty_id", specialty_id)
                    .executeAndFetchFirst(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorByRating(double rating) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM doctors WHERE rating = :rating;")
                    .addParameter("rating",rating)
                    .executeAndFetchFirst(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorViaHospitalById(int doctor_id, int hospital_id) {
        String sql = "SELECT public.doctors.* FROM doctors JOIN hospitals.doctors ON hospitals.doctors.doctor_id = public.doctors.id WHERE hospitals.doctors.hospital_id = :hospital_id AND public.doctors.id = :doctor_id;";
        try(Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("hospital_id",hospital_id)
                    .executeAndFetchFirst(Doctor.class);
        }
    }

    @Override
    public Doctor findADoctorViaPaymentById(int doctor_id, int payment_id) {
        String sql = "SELECT public.doctors.* FROM doctors JOIN doctors.payments ON doctors.payments.doctor_id = public.doctors.id WHERE doctors.payments.payment_id = :payment_id AND public.doctors.id = :doctor_id;";
        try (Connection connection = sql2o.open()) {
            return connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("payment_id",payment_id)
                    .executeAndFetchFirst(Doctor.class);
        }
    }



    @Override
    public void update(Doctor doctor) {
        String sql = "UPDATE doctors SET (doc_name, qualification, email, phone_number, consultation_fee, rating, location_id, specialty_id, specialty_name, image_url) = (:doc_name, :qualification, :email, :phone_number, :consultation_fee, :rating, :location_id, :specialty_id, :specialty_name, :image_url) WHERE id = :id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(doctor)
                    .executeUpdate();
        }
    }

    @Override
    public void updateADoctorWithNewHospital(int doctor_id, int hospital_id) {
        String sql ="UPDATE hospitals.doctors SET (doctor_id,hospital_id) = (:doctor_id,:hospital_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("hospital_id",hospital_id)
                    .executeUpdate();
        }
    }

    @Override
    public void updateADoctorWithNewPayment(int doctor_id, int payment_id) {
        String sql ="UPDATE doctors.payments SET (doctor_id,payment_id) = (:doctor_id,:payment_id);";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("payment_id",payment_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM doctors WHERE id = :id; DELETE FROM hospitals.doctors WHERE doctor_id = :id; DELETE FROM doctors.payments WHERE doctor_id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteADoctorFromHospital(int doctor_id, int hospital_id) {
        String sql ="DELETE FROM hospitals.doctors WHERE doctor_id = :doctor_id AND hospital_id = :hospital_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("hospital_id",hospital_id)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteAPaymentFromDoctor(int doctor_id, int payment_id) {
        String sql ="DELETE FROM doctors.payments WHERE doctor_id = :doctor_id AND payment_id = :payment_id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .addParameter("doctor_id",doctor_id)
                    .addParameter("payment_id",payment_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM doctors; TRUNCATE TABLE hospitals.doctors; TRUNCATE TABLE doctors.payments;")
                    .executeUpdate();
        }
    }

    @Override
    public void clearAllDoctorsInAHospital(int hospital_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM hospitals.doctors WHERE hospital_id = :hospital_id;")
                    .addParameter("hospital_id",hospital_id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAPaymentFromAllDoctors(int payment_id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM doctors.payments WHERE payment_id = :payment_id;")
                    .addParameter("payment_id",payment_id)
                    .executeUpdate();
        }
    }
}
