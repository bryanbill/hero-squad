package dao;

import interfaces.ISpeciality;
import models.Specialty;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class SpecialtyDao implements ISpeciality {

    private final Sql2o sql2o;

    public SpecialtyDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(Specialty specialty) {
        String sql = "INSERT INTO specialties (name) VALUES (:name);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(specialty)
                    .executeUpdate()
                    .getKey();
            specialty.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public List<Specialty> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specialties;")
                    .executeAndFetch(Specialty.class);
        }
    }

    @Override
    public Specialty findASpecialtyByName(String name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specialties WHERE name = :name;")
                    .addParameter("name",name)
                    .executeAndFetchFirst(Specialty.class);
        }
    }

    @Override
    public Specialty findASpecialtyById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM specialties WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(Specialty.class);
        }
    }

    @Override
    public void update(Specialty specialty) {
        String sql = "UPDATE specialties SET (name) = (:name) WHERE id = :id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(specialty)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM specialties WHERE id = :id; DELETE FROM hospitals.specialties WHERE specialty_id = :id; DELETE FROM locations.specialties WHERE specialty_id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM specialties; TRUNCATE TABLE hospitals.specialties; TRUNCATE TABLE locations.specialties;")
                    .executeUpdate();
        }
    }
}
