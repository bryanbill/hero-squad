package dao;

import interfaces.IUser;
import models.Users;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class UserDao implements IUser {
    private final Sql2o sql2o;

    public UserDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void register(Users user) {
        try(Connection connection = sql2o.open()) {
            int id = (int) connection.createQuery("INSERT INTO users (name, email, password, role) VALUES (:name, :email, :password, :role);",true)
                    .bind(user)
                    .executeUpdate()
                    .getKey();
            user.setId(id);
        } catch (Exception exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public Users login(String email) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM users WHERE email = :email;")
                    .addParameter("email", email)
                    .executeAndFetchFirst(Users.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Sql2oException("Error logging in");
        }
    }

    @Override
    public Users getUser(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM users WHERE id = :id;")
                    .addParameter("id", id)
                    .executeAndFetchFirst(Users.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Sql2oException("Error getting user");
        }
    }

    /**
     * @param role;
     * @return List<Users>
     */
    @Override
    public List<Users> getUsersByRole(String role) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM users where role = :role;")
                    .addParameter("role", role)
                    .executeAndFetch(Users.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Sql2oException("Error getting all users");
        }
    }

    @Override
    public List<Users> getAllUsers() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM users;")
                    .executeAndFetch(Users.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Sql2oException("Error getting all users");
        }
    }

    @Override
    public boolean updateUser(Users user) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("UPDATE users SET name = :name WHERE id = :id;")
                    .bind(user)
                    .executeUpdate().getResult() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            throw new Sql2oException("Error updating user");
        }
    }

    @Override
    public Users deleteUser(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("DELETE FROM users WHERE id = :id;")
                    .addParameter("id", id)
                    .executeAndFetchFirst(Users.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Sql2oException("Error deleting user");
        }
    }
}
