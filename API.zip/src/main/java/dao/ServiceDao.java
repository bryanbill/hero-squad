package dao;

import interfaces.IService;
import models.Service;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.Sql2oException;

import java.util.List;

public class ServiceDao implements IService {

    private final Sql2o sql2o;

    public ServiceDao(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void add(Service service) {
        String sql = "INSERT INTO services (name) VALUES (:name);";
        try (Connection connection = sql2o.open()){
            int id = (int) connection.createQuery(sql,true)
                    .bind(service)
                    .executeUpdate()
                    .getKey();
            service.setId(id);
        } catch (Sql2oException exception){
            System.out.println(exception.getMessage());
        }
    }

    @Override
    public List<Service> getAll() {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM services;")
                    .executeAndFetch(Service.class);
        }
    }

    @Override
    public Service findAServiceByName(String name) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM services WHERE name = :name;")
                    .addParameter("name",name)
                    .executeAndFetchFirst(Service.class);
        }
    }

    @Override
    public Service findAServiceById(int id) {
        try(Connection connection = sql2o.open()) {
            return connection.createQuery("SELECT * FROM services WHERE id = :id;")
                    .addParameter("id",id)
                    .executeAndFetchFirst(Service.class);
        }
    }

    @Override
    public void update(Service service) {
        String sql = "UPDATE services SET (name) = (:name) WHERE id = :id;";
        try(Connection connection = sql2o.open()) {
            connection.createQuery(sql)
                    .bind(service)
                    .executeUpdate();
        }
    }

    @Override
    public void deleteById(int id) {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM services WHERE id = :id; DELETE FROM hospitals.services WHERE services_id = :id; DELETE FROM locations.services WHERE services_id = :id;")
                    .addParameter("id",id)
                    .executeUpdate();
        }
    }

    @Override
    public void clearAll() {
        try(Connection connection = sql2o.open()) {
            connection.createQuery("DELETE FROM services; TRUNCATE TABLE hospitals.services; TRUNCATE TABLE locations.services;")
                    .executeUpdate();
        }
    }
}
