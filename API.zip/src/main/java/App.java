import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.gson.Gson;
import dao.*;
import exceptions.ApiException;
import models.*;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import spark.Filter;
import utils.Hasher;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static spark.Spark.*;
import static utils.Hasher.testUsingEmailValidator;


public class App {
    // CORS CONFIGURATION
    private static final HashMap<String, String> corsHeaders = new HashMap<String, String>();

    static {
        corsHeaders.put("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
        corsHeaders.put("Access-Control-Allow-Origin", "*");
        corsHeaders.put("Access-Control-Allow-Headers",
                "Content-Type,Authorization,X-Requested-With,Content-Length,Accept,Origin,");
        corsHeaders.put("Access-Control-Allow-Credentials", "true");
    }

    public final static void apply() {
        Filter filter = (request, response) -> corsHeaders.forEach((key, value) -> {
            response.header(key, value);
        });
        after(filter);
    }

    public static void main(String[] args) {
        Connection connection;
        Gson gson = new Gson();

        apply();

        String connectionString = "jdbc:postgresql://localhost:5432/mpate_daktari";
        Sql2o sql2o = new Sql2o(connectionString, "bill", "<cocoginger45");

        DoctorDao doctorDao = new DoctorDao(sql2o);
        HospitalDao hospitalDao = new HospitalDao(sql2o);
        LocationDao locationDao = new LocationDao(sql2o);
        PaymentDao paymentDao = new PaymentDao(sql2o);
        ServiceDao serviceDao = new ServiceDao(sql2o);
        SpecialtyDao specialtyDao = new SpecialtyDao(sql2o);
        SpecificLocationDao specificLocationDao = new SpecificLocationDao(sql2o);
        UserDao userDao = new UserDao(sql2o);


        //ACCESS LEVELS: VIEW,VIEW-EDIT-RATING,ADMIN
        /**
         *
         * USER ROUTES:GET,PATCH,POST,DELETE
         *
         */

        //LOGIN USER
        post("/users/login", "application/json", (req, res) -> {
            Users userData = gson.fromJson(req.body(), Users.class);
            Users user = userDao.login(userData.getEmail());
            if (user != null && Hasher.verify(userData.getPassword(), user.getPassword())) {
                String token = Hasher.createJwt(user);
                Map<String, Object> map = new HashMap<>();
                map.put("token", token);
                map.put("user", user);
                return gson.toJson(map);
            } else {
                System.out.println("User not found");
                res.status(401);
                return gson.toJson("Invalid email or password");
            }
        });

        //REGISTER USER
        post("/users/register", "application/json", (req, res) -> {
            Users user = gson.fromJson(req.body(), Users.class);
            if (testUsingEmailValidator(user.getEmail())) {
                user.setPassword(Hasher.hash(user.getPassword()));
                if (user.getRole() == null) {
                    user.setRole("VIEW-EDIT-RATING");
                }
                userDao.register(user);
                res.status(201);
                return gson.toJson(user);
            } else {
                return gson.toJson("Invalid email");
            }
        });

        //UPDATE USER
        patch("/users", "application/json", (req, res) -> {
            // Get token from header
            String token = req.headers("Authorization").split(" ")[1];
            // Verify token
            DecodedJWT jwt = Hasher.decodeJwt(token);
            Users userData = gson.fromJson(req.body(), Users.class);
            userData.setId(jwt.getClaim("id").asInt());
            Map<String, Object> map = new HashMap<>();
            if (userDao.updateUser(userData)) {
                map.put("user", userData);
                map.put("message", "User updated successfully");
                return gson.toJson(map);
            }
            res.status(400);
            return gson.toJson("Bad Request");
        });

        //GET USER
        get("/users", "application/json", (req, res) -> {
            // Get token from header
            String token = req.headers("Authorization").split(" ")[1];
            // Verify token
            DecodedJWT jwt = Hasher.decodeJwt(token);
            int id = jwt
                    .getClaim("id")
                    .asInt();
            Users user = userDao.getUser(id);
            if (user != null) {
                return gson.toJson(user);
            }
            res.status(400);
            return gson.toJson("Bad Request");
        });

        get("/users/:id", "application/json", (req, res) -> {
            int id = Integer.parseInt(req.params(":id"));
            Users user = userDao.getUser(id);
            res.type("application/json");
            if (user != null) {
                return gson.toJson(user);
            }
            res.status(400);
            return gson.toJson("Bad Request");
        });

        //GET ALL USERS
        //RESTRICTED : ADMIN ACCESS ONLY
        get("/users/list/all", "application/json", (req, res) -> {
            // Get token from header
            String token = req.headers("Authorization").split(" ")[1];
            // Verify token
            DecodedJWT jwt = Hasher.decodeJwt(token);
            int id = jwt
                    .getClaim("id")
                    .asInt();
            List<Users> user = userDao.getAllUsers();
            if (user != null) {
                return gson.toJson(user);
            }
            res.status(400);
            return gson.toJson("Bad Request");
        });

        //GET USER BY ROLE
        // RESTRICTED : ADMIN ACCESS ONLY
        get("/users/role/:id", "application/json", (req, res) -> {
            List<Users> user = userDao.getUsersByRole(req.params(":id"));
            if (user != null) {
                return gson.toJson(user);
            }
            res.status(400);
            return gson.toJson("Bad Request");
        });

        //DELETE A USER
        // RESTRICTED : ADMIN ACCESS ONLY

      // NOTE: This path is not protected
        delete("/users", "application/json", (req, res) -> {
            // Get token from header
            String token = req.headers("Authorization");
            // Verify token
            DecodedJWT jwt = Hasher.decodeJwt(token);
            int id = Integer.parseInt(jwt.getClaim("id").asString());
            Users user = userDao.deleteUser(id);
            if (user != null) {
                return gson.toJson(user);
            }
            res.status(400);
            return gson.toJson("Bad Request");
        });

        /**
         *
         * DOCTOR ROUTES: GET,PATCH,POST,DELETE
         *
         */

        //ADD A DOCTOR :
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/doctors", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                Doctor doctor = gson.fromJson(req.body(), Doctor.class);
                doctorDao.add(doctor);
                res.status(201);
                return gson.toJson(doctor);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL DOCTORS
        get("/doctors", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(doctorDao.getAll());
        });

        //VIEW ALL DOCTORS IN A LOCATION
        get("/doctors/:location_id", "application/json", (req, res) -> {
            int location_id = Integer.parseInt(req.params("location_id"));
            List<Doctor> doctor = doctorDao.getAllDoctorsInALocation(location_id);
            if (doctor == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //VIEW ALL DOCTORS BY A SPECIALTY
        get("/doctors/specialties/:specialty_id", "application/json", (req, res) -> {
            int specialty_id = Integer.parseInt(req.params("specialty_id"));
            List<Doctor> doctor = doctorDao.getAllDoctorsWithASpeciality(specialty_id);
            if (doctor == null ){
                return gson.toJson("No specialty with that ID exists");
            }
            return gson.toJson(doctor);
        });

        ///VIEW ALL DOCTORS BY SPECIALTY IN A LOCATION
        get("/locations/:location_id/specialties/doctors/:specialty_id", "application/json", (req, res)->{
            int specialty_id = Integer.parseInt(req.params(":specialty_id"));
            int location_id = Integer.parseInt(req.params(":location_id"));
            List<Doctor> doctors = doctorDao.getAllDoctorsBySpecialtyInLocation(location_id, specialty_id);
            if (doctors == null){
                return gson.toJson("No doctor/specialty with that ID exists");
            }
            return gson.toJson(doctors);
        });

        //VIEW ALL DOCTORS BY A LOCATION/SPECIALTY
        get("/locations/:location_id/specialities/doctors/:speciality_id", "application/json", (req, res)->{
            int specialityId = Integer.parseInt(req.params(":speciality_id"));
            int locationId = Integer.parseInt(req.params(":location_id"));
            List<Doctor> allDoctorsBySpeciality;
            if (specialtyDao == null){
                return gson.toJson(String.format("No speciality with the id: \"%s\" exists", req.params("id")));
            }
            allDoctorsBySpeciality = doctorDao.getAllDoctorsBySpecialtyInLocation(locationId, specialityId);
            return gson.toJson(allDoctorsBySpeciality);
        });


        //FIND A DOCTOR BY ID
        get("/doctors/id/:id", "application/json", (req, res) -> {
            int doctor_id = Integer.parseInt(req.params("id"));
            Doctor doctor = doctorDao.findADoctorById(doctor_id);
            if (doctor == null) {
                return gson.toJson("No doctor with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //FIND A DOCTOR BY NAME
        get("/doctors/names/:doc_name", "application/json", (req, res) -> {
            String doc_name = req.params("doc_name");
            Doctor doctor = doctorDao.findADoctorByName(doc_name);
            if (doctor == null) {
                return gson.toJson("No doctor with that NAME exists");
            }
            return gson.toJson(doctor);
        });

        //FIND A DOCTOR BY LOCATION
        get("/doctors/:doctor_id/:location_id", "application/json", (req, res) -> {
            int doctor_id = Integer.parseInt(req.params("doctor_id"));
            int location_id = Integer.parseInt(req.params("location_id"));
            Doctor doctor = doctorDao.findADoctorByLocation(doctor_id, location_id);
            if (doctor == null) {
                return gson.toJson("No doctor/location with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //FIND A DOCTOR BY SPECIALITY
        get("/doctors/specialty/:doctor_id/:specialty_id", "application/json", (req, res) -> {
            int doctor_id = Integer.parseInt(req.params("doctor_id"));
            int specialty_id = Integer.parseInt(req.params("specialty_id"));
            Doctor doctor = doctorDao.findADoctorBySpeciality(doctor_id, specialty_id);
            if (doctor == null) {
                return gson.toJson("No doctor/specialty with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //UPDATE A DOCTOR
        // RESTRICTED : ADMIN ACCESS & LOGGED IN USERS
        patch("/doctors/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                Doctor doctor = gson.fromJson(req.body(), Doctor.class);
                doctor.setId(Integer.parseInt(req.params("id")));
                doctorDao.update(doctor);
                res.status(201);
                res.type("application/json");
                return gson.toJson(doctor);
            }
            return gson.toJson("Please Login");
        });

        //DELETE A DOCTOR
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/doctors/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                doctorDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(doctorDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });

        //ADD A DOCTOR TO A HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        post("/doctors/hospital/add/:doctor_id/:hospital_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int doctor_id = Integer.parseInt(req.params("doctor_id"));
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                doctorDao.addDoctorToHospital(doctor_id, hospital_id);
                res.status(201);
                return gson.toJson("Doctor successfully added");
            }
            return gson.toJson("Admin Access Only");

        });

        //ADD A PAYMENT METHOD TO A DOCTOR
        //RESTRICTED: ADMIN ACCESS ONLY
        post("/doctors/payment/add/:doctor_id/:payment_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int doctor_id = Integer.parseInt(req.params("doctor_id"));
                int payment_id = Integer.parseInt(req.params("payment_id"));
                doctorDao.addPaymentToDoctor(doctor_id, payment_id);
                res.status(201);
                return gson.toJson("Payment successfully added");
            }
            return gson.toJson("Admin Access Only");

        });

        //GET ALL HOSPITALS FOR A DOCTOR
        get("/hospitals/all/doctors/:doctor_id", "application/json", (req, res) -> {
            int doctor_id = Integer.parseInt(req.params("doctor_id"));
            List<Hospital> doctor = doctorDao.getAllHospitalsForADoctor(doctor_id);
            if (doctor == null) {
                return gson.toJson("No doctor with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //GET ALL DOCTORS IN A HOSPITAL
        get("/doctors/all/hospital/:hospital_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            List<Doctor> doctor = doctorDao.getAllDoctorsInHospital(hospital_id);
            if (doctor == null ){
                return gson.toJson("No doctor in the hospital with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //GET ALL PAYMENTS FOR A DOCTOR
        get("/doctors/:doctor_id", "application/json", (req, res) -> {
            int doctor_id = Integer.parseInt(req.params("doctor_id"));
            List<Payment> doctor = doctorDao.getAllPaymentsForADoctor(doctor_id);
            if (doctor == null) {
                return gson.toJson("No doctor with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //GET ALL DOCTORS USING A PAYMENT
        get("/doctors/:payment_id", "application/json", (req, res) -> {
            int payment_id = Integer.parseInt(req.params("payment_id"));
            List<Doctor> doctor = doctorDao.getAllDoctorsUsingAPayment(payment_id);
            if (doctor == null) {
                return gson.toJson("No payment with that ID exists");
            }
            return gson.toJson(doctor);
        });

        //UPDATE DOCTOR WITH NEW HOSPITAL
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/doctors/hospital/:doctor_id/:hospital_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int doctor_id = Integer.parseInt(req.params("doctor_id"));
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                doctorDao.updateADoctorWithNewHospital(doctor_id, hospital_id);
                res.status(201);
                return gson.toJson("Doctor successfully updated");
            }
            return gson.toJson("Admin Access Only");
        });

        //UPDATE DOCTOR WITH NEW PAYMENT
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/doctors/payment/:doctor_id/:payment_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int doctor_id = Integer.parseInt(req.params("doctor_id"));
                int payment_id = Integer.parseInt(req.params("payment_id"));
                doctorDao.updateADoctorWithNewHospital(doctor_id, payment_id);
                res.status(201);
                return gson.toJson("Doctor successfully updated");
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE DOCTOR FROM HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        delete("/doctors/hospital/:doctor_id/:hospital_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int doctor_id = Integer.parseInt(req.params("doctor_id"));
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                doctorDao.deleteADoctorFromHospital(doctor_id, hospital_id);
                res.status(201);
                return gson.toJson("Doctor successfully deleted");
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE PAYMENT FROM DOCTOR
        //RESTRICTED: ADMIN ACCESS ONLY
        delete("/doctors/payment/:doctor_id/:payment_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int doctor_id = Integer.parseInt(req.params("doctor_id"));
                int payment_id = Integer.parseInt(req.params("payment_id"));
                doctorDao.deleteAPaymentFromDoctor(doctor_id, payment_id);
                res.status(201);
                return gson.toJson("Payment successfully deleted");
            }
            return gson.toJson("Admin Access Only");
        });

        /**
         *
         * LOCATION ROUTES: GET,PATCH,POST,DELETE
         *
         */

        //ADD LOCATION
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/locations", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                Location location = gson.fromJson(req.body(), Location.class);
                locationDao.add(location);
                res.status(201);
                return gson.toJson(location);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL LOCATIONS
        get("/locations", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(locationDao.getAll());
        });

        //FIND A LOCATION BY ID
        get("/locations/:id", "application/json", (req, res) -> {
            int id = Integer.parseInt(req.params("id"));
            Location location = locationDao.findALocationById(id);
            if (location == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(location);
        });

        //FIND LOCATION BY NAME
        get("/locations/names/:location_name", "application/json", (req, res)->{
            String name = req.params("location_name");
            Location location = locationDao.findALocationByName(name);
            if (location == null) {
                return gson.toJson("No location with that NAME exists");
            }
            return gson.toJson(location);
        });

        //UPDATE LOCATION
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/locations/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                Location location = gson.fromJson(req.body(), Location.class);
                location.setId(Integer.parseInt(req.params("id")));
                locationDao.update(location);
                res.status(201);
                res.type("application/json");
                return gson.toJson(location);
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE LOCATION
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/locations/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                locationDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(locationDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });

        /**
         *
         * HOSPITAL ROUTES: GET,PATCH,POST,DELETE
         *
         */

        //ADD A HOSPITAL :
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/hospitals", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                Hospital hospital = gson.fromJson(req.body(), Hospital.class);
                hospitalDao.add(hospital);
                res.status(201);
                return gson.toJson(hospital);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL HOSPITALS
        get("/hospitals", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(hospitalDao.getAll());
        });

        //VIEW ALL HOSPITALS IN A LOCATION
        get("/hospitals/:location_id", "application/json", (req, res) -> {
            int location_id = Integer.parseInt(req.params("location_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsInALocation(location_id);
            if (hospital == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //VIEW ALL HOSPITALS IN A SPECIFIC LOCATION
        get("/hospitals/locations/:specificlocation_id", "application/json", (req, res) -> {
            int specificlocation_id = Integer.parseInt(req.params("specificlocation_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsInASpecificLocation(specificlocation_id);
            if (hospital == null ){
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //VIEW ALL HOSPITALS BY A SPECIALTY
        get("/hospitals/:specialty_id", "application/json", (req, res) -> {
            int specialty_id = Integer.parseInt(req.params("specialty_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsWithASpecialty(specialty_id);
            if (hospital == null) {
                return gson.toJson("No specialty with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //VIEW ALL HOSPITALS BY A SERVICES
        get("/hospitals/services/:services_id", "application/json", (req, res) -> {
            int services_id = Integer.parseInt(req.params("services_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsWithAService(services_id);
            if (hospital == null) {
                return gson.toJson("No service with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //VIEW ALL HOSPITALS BY A LOCATION/SERVICES
        get("/locations/:location_id/services/hospitals/:services_id", "application/json", (req, res)->{
            int servicesId = Integer.parseInt(req.params(":services_id"));
            int locationId = Integer.parseInt(req.params(":location_id"));
            List<Hospital> allHospitalsByLocationAndService;
            if (serviceDao == null){
                throw new ApiException(404, String.format("No service with the id: \"%s\" exists", req.params("id")));
            }
            allHospitalsByLocationAndService = hospitalDao.getAllHospitalsByServiceInLocation(locationId, servicesId);
            return gson.toJson(allHospitalsByLocationAndService);
        });

        //VIEW ALL HOSPITALS BY A SPECIFIC LOCATION/SERVICES
        get("/specificlocations/:specificlocation_id/services/hospitals/:services_id", "application/json", (req, res)->{
            int servicesId = Integer.parseInt(req.params(":services_id"));
            int specificlocationId = Integer.parseInt(req.params(":specificlocation_id"));
            List<Hospital> allHospitalsBySpecificLocationAndService;
            if (serviceDao == null){
                throw new ApiException(404, String.format("No service with the id: \"%s\" exists", req.params("id")));
            }
            allHospitalsBySpecificLocationAndService = hospitalDao.getAllHospitalsByServiceInSpecificLocation(specificlocationId, servicesId);
            return gson.toJson(allHospitalsBySpecificLocationAndService);
        });

        //VIEW ALL HOSPITALS BY A  LOCATION/PAYMENT/SERVICES
        //VIEW ALL HOSPITALS BY A SPECIFIC LOCATION/PAYMENT/SERVICES


        //FIND A HOSPITAL BY ID
        get("/hospitals/:id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("id"));
            Hospital hospital = hospitalDao.findAHospitalById(hospital_id);
            if (hospital == null) {
                return gson.toJson("No hospital with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //FIND A HOSPITAL BY NAME
        get("/hospitals/names/:name", "application/json", (req, res) -> {
            String name = req.params("name");
            Hospital hospital = hospitalDao.findAHospitalByName(name);
            if (hospital == null) {
                return gson.toJson("No hospital with that NAME exists");
            }
            return gson.toJson(hospital);
        });

        //FIND A HOSPITAL BY LOCATION
        get("/hospitals/:hospital_id/:location_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            int location_id = Integer.parseInt(req.params("location_id"));
            Hospital hospital = hospitalDao.findAHospitalByLocation(hospital_id, location_id);
            if (hospital == null) {
                return gson.toJson("No hospital/location with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //FIND A HOSPITAL BY SPECIFIC LOCATION
        get("/hospitals/:hospital_id/:specificlocation_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            int specificlocation_id = Integer.parseInt(req.params("specificlocation_id"));
            Hospital hospital = hospitalDao.findAHospitalBySpecificLocation(hospital_id, specificlocation_id);
            if (hospital == null) {
                return gson.toJson("No hospital/specific location with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //FIND A HOSPITAL BY SPECIALITY
        get("/hospitals/:hospital_id/:speciality_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            int speciality_id = Integer.parseInt(req.params("location_id"));
            Hospital hospital = hospitalDao.findAHospitalViaSpecialtyById(hospital_id, speciality_id);
            if (hospital == null) {
                return gson.toJson("No hospital/speciality with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //UPDATE A HOSPITAL
        // RESTRICTED : ADMIN ACCESS & LOGGED IN USERS
        patch("/hospitals/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                Hospital hospital = gson.fromJson(req.body(), Hospital.class);
                hospital.setId(Integer.parseInt(req.params("id")));
                hospitalDao.update(hospital);
                res.status(201);
                res.type("application/json");
                return gson.toJson(hospital);
            }
            return gson.toJson("Please Login");
        });

        //DELETE A HOSPITAL
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/hospitals/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                hospitalDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(hospitalDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });

        //ADD A SERVICE TO A HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        post("/services/hospital/:services_id/:hospital_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int services_id = Integer.parseInt(req.params("services_id"));
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                hospitalDao.addServiceToHospital(services_id, hospital_id);
                res.status(201);
                return gson.toJson("Service successfully added");
            }
            return gson.toJson("Admin Access Only");

        });

        //ADD A SPECIALTY TO A HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        post("/specialties/hospital/:specialty_id/:hospital_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int specialty_id = Integer.parseInt(req.params("specialty_id"));
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                hospitalDao.addSpecialtyToHospital(specialty_id, hospital_id);
                res.status(201);
                return gson.toJson("Specialty successfully added");
            }
            return gson.toJson("Admin Access Only");

        });

        //ADD A PAYMENT METHOD TO A HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        post("/hospitals/payment/:hospital_id/:payment_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int payment_id = Integer.parseInt(req.params("payment_id"));
                hospitalDao.addPaymentToHospital(hospital_id, payment_id);
                res.status(201);
                return gson.toJson("Payment successfully added");
            }
            return gson.toJson("Admin Access Only");

        });

        //GET ALL PAYMENTS FOR A HOSPITAL
        get("/payments/:hospital_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            List<Payment> hospital = hospitalDao.getAllPaymentsForAHospital(hospital_id);
            if (hospital == null) {
                return gson.toJson("No hospital with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //GET ALL SERVICES IN A HOSPITAL
        get("/services/:hospital_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            List<Service> hospital = hospitalDao.getAllServicesInAHospital(hospital_id);
            if (hospital == null) {
                return gson.toJson("No hospital with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //GET ALL SPECIALTIES IN A HOSPITAL
        get("/specialties/:hospital_id", "application/json", (req, res) -> {
            int hospital_id = Integer.parseInt(req.params("hospital_id"));
            List<Specialty> hospital = hospitalDao.getAllSpecialtiesInAHospital(hospital_id);
            if (hospital == null) {
                return gson.toJson("No hospital with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //GET ALL HOSPITALS USING A PAYMENT
        get("/payments/hospitals/:payment_id", "application/json", (req, res) -> {
            int payment_id = Integer.parseInt(req.params("payment_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsUsingAPayment(payment_id);
            if (hospital == null) {
                return gson.toJson("No payment with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //GET ALL HOSPITALS IN A LOCATION USING A PAYMENT
        get("/locations/:location_id/payments/hospitals/:payment_id", "application/json", (req, res) -> {
            int payment_id = Integer.parseInt(req.params("payment_id"));
            int location_id = Integer.parseInt(req.params("location_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsInLocationUsingAPayment(payment_id, location_id);
            if (hospital == null ){
                return gson.toJson("No payment with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //GET ALL HOSPITALS IN A SPECIFIC LOCATION USING A PAYMENT
        get("/specificlocations/:specificlocation_id/payments/hospitals/:payment_id", "application/json", (req, res) -> {
            int payment_id = Integer.parseInt(req.params("payment_id"));
            int specificlocation_id = Integer.parseInt(req.params("specificlocation_id"));
            List<Hospital> hospital = hospitalDao.getAllHospitalsInSpecificLocationUsingAPayment(payment_id, specificlocation_id);
            if (hospital == null ){
                return gson.toJson("No payment with that ID exists");
            }
            return gson.toJson(hospital);
        });

        //UPDATE HOSPITAL WITH NEW PAYMENT
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/hospitals/payment/:hospital_id/:payment_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int payment_id = Integer.parseInt(req.params("payment_id"));
                hospitalDao.updateAHospitalWithNewPayment(hospital_id, payment_id);
                res.status(201);
                return gson.toJson("Hospital successfully updated");
            }
            return gson.toJson("Admin Access Only");
        });

        //UPDATE HOSPITAL WITH NEW SERVICE
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/hospitals/services/:hospital_id/:services_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int services_id = Integer.parseInt(req.params("services_id"));
                hospitalDao.updateHospitalWithNewService(hospital_id, services_id);
                res.status(201);
                return gson.toJson("Hospital successfully updated");
            }
            return gson.toJson("Admin Access Only");
        });

        //UPDATE HOSPITAL WITH NEW SPECIALTY
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/hospitals/specialty/:hospital_id/:specialty_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int specialty_id = Integer.parseInt(req.params("specialty_id"));
                hospitalDao.updateHospitalWithNewSpecialty(hospital_id, specialty_id);
                res.status(201);
                return gson.toJson("Hospital successfully updated");
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE PAYMENT FROM HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        delete("/hospitals/payment/:hospital_id/:payment_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int payment_id = Integer.parseInt(req.params("payment_id"));
                hospitalDao.deleteAPaymentFromHospital(hospital_id, payment_id);
                res.status(201);
                return gson.toJson("Payment successfully deleted");
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE SERVICE FROM HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        delete("/hospitals/services/:hospital_id/:services_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int services_id = Integer.parseInt(req.params("services_id"));
                hospitalDao.deleteServiceFromHospital(hospital_id, services_id);
                res.status(201);
                return gson.toJson("Service successfully deleted");
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE SPECIALTY FROM HOSPITAL
        //RESTRICTED: ADMIN ACCESS ONLY
        delete("/hospitals/specialty/:hospital_id/:specialty_id", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                int hospital_id = Integer.parseInt(req.params("hospital_id"));
                int specialty_id = Integer.parseInt(req.params("specialty_id"));
                hospitalDao.deleteSpecialtyFromHospital(hospital_id, specialty_id);
                res.status(201);
                return gson.toJson("Specialty successfully deleted");
            }
            return gson.toJson("Admin Access Only");
        });

        /**
         *
         * PAYMENT ROUTES
         *
         */

        //ADD PAYMENT
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/payments", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                Payment payment = gson.fromJson(req.body(), Payment.class);
                paymentDao.add(payment);
                res.status(201);
                return gson.toJson(payment);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL PAYMENTS
        get("/payments", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(paymentDao.getAll());
        });

        //FIND A PAYMENT BY ID
        get("/payments/:id", "application/json", (req, res) -> {
            int id = Integer.parseInt(req.params("id"));
            Payment payment = paymentDao.findAPaymentById(id);
            if (payment == null) {
                return gson.toJson("No payment with that ID exists");
            }
            return gson.toJson(payment);
        });

        //FIND PAYMENT BY NAME
        get("/payments/names/:payment_name", "application/json", (req, res) -> {
            String name = req.params("name");
            Payment payment = paymentDao.findAPaymentByName(name);
            if (payment == null) {
                return gson.toJson("No payment with that NAME exists");
            }
            return gson.toJson(payment);
        });

        //UPDATE PAYMENT
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/payments/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                Payment payment = gson.fromJson(req.body(), Payment.class);
                payment.setId(Integer.parseInt(req.params("id")));
                paymentDao.update(payment);
                res.status(201);
                res.type("application/json");
                return gson.toJson(payment);
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE PAYMENT
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/payments/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                paymentDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(paymentDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });

        /**
         *
         * SERVICE ROUTES
         *
         */

        //ADD SERVICE
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/services", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                Service service = gson.fromJson(req.body(), Service.class);
                serviceDao.add(service);
                res.status(201);
                return gson.toJson(service);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL SERVICES
        get("/services", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(serviceDao.getAll());
        });

        //VIEW ALL SERVICES IN A LOCATION
        get("/services/:location_id", "application/json", (req, res) -> {
            int location_id = Integer.parseInt(req.params("location_id"));
            List<Service> service = locationDao.getAllServicesInALocation(location_id);
            if (service == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(service);
        });

        //FIND A SERVICE BY ID
        get("/services/:id", "application/json", (req, res) -> {
            int id = Integer.parseInt(req.params("id"));
            Service service = serviceDao.findAServiceById(id);
            if (service == null) {
                return gson.toJson("No service with that ID exists");
            }
            return gson.toJson(service);
        });

        //FIND SERVICE BY NAME
        get("/services/names/:service_name", "application/json", (req, res) -> {
            String name = req.params("name");
            Service service = serviceDao.findAServiceByName(name);
            if (service == null) {
                return gson.toJson("No service with that NAME exists");
            }
            return gson.toJson(service);
        });

        //FIND A SERVICE BY LOCATION
        get("/services/:services_id/:location_id", "application/json", (req, res) -> {
            int services_id = Integer.parseInt(req.params("services_id"));
            int location_id = Integer.parseInt(req.params("location_id"));
            Service service = locationDao.findAServiceViaLocationById(location_id, services_id);
            if (service == null) {
                return gson.toJson("No service/location with that ID exists");
            }
            return gson.toJson(service);
        });

        //UPDATE SERVICE
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/services/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                Service service = gson.fromJson(req.body(), Service.class);
                service.setId(Integer.parseInt(req.params("id")));
                serviceDao.update(service);
                res.status(201);
                res.type("application/json");
                return gson.toJson(service);
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE SERVICE
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/services/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                serviceDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(serviceDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });

        /**
         *
         * SPECIFIC LOCATION ROUTES
         *
         */

        //ADD SPECIFIC LOCATION
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/specificlocations", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                SpecificLocation specificLocation = gson.fromJson(req.body(), SpecificLocation.class);
                specificLocationDao.add(specificLocation);
                res.status(201);
                return gson.toJson(specificLocation);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL SPECIFIC LOCATIONS IN A LOCATION
        get("/specificlocations/:location_id", "application/json", (req, res) -> {
            int location_id = Integer.parseInt(req.params("location_id"));
            List<SpecificLocation> specificLocation = specificLocationDao.getAllByLocation(location_id);
            if (specificLocation == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(specificLocation);
        });

        //VIEW ALL SPECIFIC LOCATIONS
        get("/specificlocations", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(specificLocationDao.getAll());
        });

        //FIND SPECIFIC LOCATION BY NAME
        get("/specificlocations/names/:specificlocation_name", "application/json", (req, res) -> {
            String name = req.params("name");
            SpecificLocation specificLocation = specificLocationDao.findASpecificLocationByName(name);
            if (specificLocation == null) {
                return gson.toJson("No specific location with that NAME exists");
            }
            return gson.toJson(specificLocationDao);
        });

        //FIND A SPECIFIC LOCATION BY ID
        get("/specificlocations/locations/:id", "application/json", (req, res) -> {
            int specificlocations_id = Integer.parseInt(req.params("id"));
            SpecificLocation specificLocation = specificLocationDao.findASpecificLocationById(specificlocations_id);
            if (specificLocation == null) {
                return gson.toJson("No  with that ID exists");
            }
            return gson.toJson(specificLocation);
        });

        //FIND SPECIFIC LOCATION BY LOCATION ID
        get("/specificlocations/locations/:location_id", "application/json", (req, res) -> {
            int location_id = Integer.parseInt(req.params("location_id"));
            SpecificLocation specificLocation = specificLocationDao.findASpecificLocationById(location_id);
            if (specificLocation == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(specificLocation);
        });

        //UPDATE SPECIFIC LOCATION
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/specificlocations/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                SpecificLocation specificLocation = gson.fromJson(req.body(), SpecificLocation.class);
                specificLocation.setId(Integer.parseInt(req.params("id")));
                specificLocationDao.update(specificLocation);
                res.status(201);
                res.type("application/json");
                return gson.toJson(specificLocation);
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE SPECIFIC LOCATION
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/specificlocations/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                specificLocationDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(specificLocationDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });

        /**
         *
         * SPECIALTY ROUTES
         *
         */

        //ADD SPECIALTY
        // RESTRICTED : ADMIN ACCESS ONLY
        post("/specialties", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                Specialty specialty = gson.fromJson(req.body(), Specialty.class);
                specialtyDao.add(specialty);
                res.status(201);
                return gson.toJson(specialty);
            }
            return gson.toJson("Admin Access Only");
        });

        //VIEW ALL SPECIALTIES
        get("/specialties", "application/json", (req, res) -> {
            res.type("application/json");
            return gson.toJson(specialtyDao.getAll());
        });

        //VIEW ALL SPECIALTIES IN A LOCATION
        get("/specialties/:location_id", "application/json", (req, res) -> {
            int location_id = Integer.parseInt(req.params("location_id"));
            List<Specialty> specialty = locationDao.getAllSpecialtiesInALocation(location_id);
            if (specialty == null) {
                return gson.toJson("No location with that ID exists");
            }
            return gson.toJson(specialty);
        });

        //FIND A SPECIALTY BY ID
        get("/specialty/:id", "application/json", (req, res) -> {
            int id = Integer.parseInt(req.params("id"));
            Specialty specialty = specialtyDao.findASpecialtyById(id);
            if (specialty == null) {
                return gson.toJson("No specialty with that ID exists");
            }
            return gson.toJson(specialty);
        });

        //FIND SPECIALTY BY NAME
        get("/specialties/names/:specialty_name", "application/json", (req, res) -> {
            String name = req.params("name");
            Specialty specialty = specialtyDao.findASpecialtyByName(name);
            if (specialty == null) {
                return gson.toJson("No specialty with that NAME exists");
            }
            return gson.toJson(specialty);
        });

        //FIND A SPECIALTY BY LOCATION
        get("/specialties/:specialty_id/:location_id", "application/json", (req, res) -> {
            int specialty_id = Integer.parseInt(req.params("specialty_id"));
            int location_id = Integer.parseInt(req.params("location_id"));
            Specialty specialty = locationDao.findASpecialtyViaLocationById(location_id, specialty_id);
            if (specialty == null) {
                return gson.toJson("No specialty/location with that ID exists");
            }
            return gson.toJson(specialty);
        });

        //UPDATE SPECIALTY
        // RESTRICTED : ADMIN ACCESS ONLY
        patch("/specialties/:id/update", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("EDIT-RATING") || accessLevel.contains("ADMIN")) {
                Specialty specialty = gson.fromJson(req.body(), Specialty.class);
                specialty.setId(Integer.parseInt(req.params("id")));
                specialtyDao.update(specialty);
                res.status(201);
                res.type("application/json");
                return gson.toJson(specialty);
            }
            return gson.toJson("Admin Access Only");
        });

        //DELETE SPECIALTY
        // RESTRICTED : ADMIN ACCESS ONLY
        delete("/specialties/:id/delete", "application/json", (req, res) -> {
            String token = req.headers("Authorization").split(" ")[1];
            DecodedJWT jwt = Hasher.decodeJwt(token);
            String accessLevel = jwt.getClaim("accessLevel").asString();

            if (accessLevel.contains("ADMIN")) {
                specialtyDao.deleteById(Integer.parseInt(req.params("id")));
                res.status(201);
                res.type("application/json");
                return gson.toJson(specialtyDao.getAll());
            }
            return gson.toJson("Admin Access Only");
        });
    }
}
