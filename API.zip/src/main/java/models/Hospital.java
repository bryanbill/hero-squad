package models;

public class Hospital {

    private int id;
    private String name;
    private String operating_hours;
    private String email;
    private String phone_number;
    private double rating;
    private int specificlocation_id;
    private int location_id;
    private String image_url;
    private String address;

    public Hospital(int id, String name, String operating_hours, String email, String phone_number, double rating, int specificlocation_id, int location_id, String image_url, String address) {
        this.id = id;
        this.name = name;
        this.operating_hours = operating_hours;
        this.email = email;
        this.phone_number = phone_number;
        this.rating = rating;
        this.specificlocation_id = specificlocation_id;
        this.location_id = location_id;
        this.image_url = image_url;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOperating_hours() {
        return operating_hours;
    }

    public void setOperating_hours(String operating_hours) {
        this.operating_hours = operating_hours;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getSpecificlocation_id() {
        return specificlocation_id;
    }

    public void setSpecificlocation_id(int specificlocation_id) {
        this.specificlocation_id = specificlocation_id;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }
}
