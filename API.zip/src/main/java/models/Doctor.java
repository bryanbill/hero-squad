package models;

public class Doctor {

    private int id;
    private String doc_name;
    private String qualification;
    private String email;
    private String phone_number;
    private String specialty_name;
    private int consultation_fee;
    private double rating;
    private int location_id;
    private int specialty_id;
    private String image_url;

    public Doctor(int id, String doc_name, String qualification, String email, String phone_number, String specialty_name, int consultation_fee, double rating, int location_id, int specialty_id, String image_url) {
        this.id = id;
        this.doc_name = doc_name;
        this.qualification = qualification;
        this.email = email;
        this.phone_number = phone_number;
        this.specialty_name = specialty_name;
        this.consultation_fee = consultation_fee;
        this.rating = rating;
        this.location_id = location_id;
        this.specialty_id = specialty_id;
        this.image_url = image_url;
    }

    public String getSpecialty_name() {
        return specialty_name;
    }

    public void setSpecialty_name(String specialty_name) {
        this.specialty_name = specialty_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDoc_name() {
        return doc_name;
    }

    public void setDoc_name(String doc_name) {
        this.doc_name = doc_name;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public int getConsultation_fee() {
        return consultation_fee;
    }

    public void setConsultation_fee(int consultation_fee) {
        this.consultation_fee = consultation_fee;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    public int getSpecialty_id() {
        return specialty_id;
    }

    public void setSpecialty_id(int specialty_id) {
        this.specialty_id = specialty_id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }
}
