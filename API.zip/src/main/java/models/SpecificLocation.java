package models;

public class SpecificLocation {
    private int id;
    private String name;
    private int location_id;

    public SpecificLocation(int id, String name, int location_id) {
        this.id = id;
        this.name = name;
        this.location_id = location_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }
}
