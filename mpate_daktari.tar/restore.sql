--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.12 (Ubuntu 12.12-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.12 (Ubuntu 12.12-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mpate_daktari;
--
-- Name: mpate_daktari; Type: DATABASE; Schema: -; Owner: x
--

CREATE DATABASE mpate_daktari WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE mpate_daktari OWNER TO x;

\connect mpate_daktari

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: doctors; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA doctors;


ALTER SCHEMA doctors OWNER TO postgres;

--
-- Name: hospitals; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hospitals;


ALTER SCHEMA hospitals OWNER TO postgres;

--
-- Name: locations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA locations;


ALTER SCHEMA locations OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: payments; Type: TABLE; Schema: doctors; Owner: postgres
--

CREATE TABLE doctors.payments (
    id integer NOT NULL,
    doctor_id integer,
    payment_id integer
);


ALTER TABLE doctors.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: doctors; Owner: postgres
--

CREATE SEQUENCE doctors.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE doctors.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: doctors; Owner: postgres
--

ALTER SEQUENCE doctors.payments_id_seq OWNED BY doctors.payments.id;


--
-- Name: doctors; Type: TABLE; Schema: hospitals; Owner: postgres
--

CREATE TABLE hospitals.doctors (
    id integer NOT NULL,
    hospital_id integer,
    doctor_id integer
);


ALTER TABLE hospitals.doctors OWNER TO postgres;

--
-- Name: doctors_id_seq; Type: SEQUENCE; Schema: hospitals; Owner: postgres
--

CREATE SEQUENCE hospitals.doctors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitals.doctors_id_seq OWNER TO postgres;

--
-- Name: doctors_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitals; Owner: postgres
--

ALTER SEQUENCE hospitals.doctors_id_seq OWNED BY hospitals.doctors.id;


--
-- Name: payments; Type: TABLE; Schema: hospitals; Owner: postgres
--

CREATE TABLE hospitals.payments (
    id integer NOT NULL,
    hospital_id integer,
    payment_id integer
);


ALTER TABLE hospitals.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: hospitals; Owner: postgres
--

CREATE SEQUENCE hospitals.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitals.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitals; Owner: postgres
--

ALTER SEQUENCE hospitals.payments_id_seq OWNED BY hospitals.payments.id;


--
-- Name: services; Type: TABLE; Schema: hospitals; Owner: postgres
--

CREATE TABLE hospitals.services (
    id integer NOT NULL,
    hospital_id integer,
    services_id integer
);


ALTER TABLE hospitals.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: hospitals; Owner: postgres
--

CREATE SEQUENCE hospitals.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitals.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitals; Owner: postgres
--

ALTER SEQUENCE hospitals.services_id_seq OWNED BY hospitals.services.id;


--
-- Name: specialties; Type: TABLE; Schema: hospitals; Owner: postgres
--

CREATE TABLE hospitals.specialties (
    id integer NOT NULL,
    hospital_id integer,
    specialty_id integer
);


ALTER TABLE hospitals.specialties OWNER TO postgres;

--
-- Name: specialties_id_seq; Type: SEQUENCE; Schema: hospitals; Owner: postgres
--

CREATE SEQUENCE hospitals.specialties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitals.specialties_id_seq OWNER TO postgres;

--
-- Name: specialties_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitals; Owner: postgres
--

ALTER SEQUENCE hospitals.specialties_id_seq OWNED BY hospitals.specialties.id;


--
-- Name: services; Type: TABLE; Schema: locations; Owner: postgres
--

CREATE TABLE locations.services (
    id integer NOT NULL,
    services_id integer,
    location_id integer
);


ALTER TABLE locations.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: locations; Owner: postgres
--

CREATE SEQUENCE locations.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE locations.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: locations; Owner: postgres
--

ALTER SEQUENCE locations.services_id_seq OWNED BY locations.services.id;


--
-- Name: specialties; Type: TABLE; Schema: locations; Owner: postgres
--

CREATE TABLE locations.specialties (
    id integer NOT NULL,
    specialty_id integer,
    location_id integer
);


ALTER TABLE locations.specialties OWNER TO postgres;

--
-- Name: specialties_id_seq; Type: SEQUENCE; Schema: locations; Owner: postgres
--

CREATE SEQUENCE locations.specialties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE locations.specialties_id_seq OWNER TO postgres;

--
-- Name: specialties_id_seq; Type: SEQUENCE OWNED BY; Schema: locations; Owner: postgres
--

ALTER SEQUENCE locations.specialties_id_seq OWNED BY locations.specialties.id;


--
-- Name: doctors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctors (
    id integer NOT NULL,
    doc_name character varying NOT NULL,
    location_id integer NOT NULL,
    specialty_id integer NOT NULL,
    specialty_name character varying NOT NULL,
    qualification character varying,
    consultation_fee integer,
    image_url character varying,
    email character varying,
    phone_number character varying,
    rating real
);


ALTER TABLE public.doctors OWNER TO postgres;

--
-- Name: doctors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doctors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.doctors_id_seq OWNER TO postgres;

--
-- Name: doctors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doctors_id_seq OWNED BY public.doctors.id;


--
-- Name: hospitals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hospitals (
    id integer NOT NULL,
    name character varying NOT NULL,
    operating_hours character varying,
    address character varying,
    location_id integer NOT NULL,
    specificlocation_id integer,
    email character varying,
    phone_number character varying,
    rating real,
    image_url character varying
);


ALTER TABLE public.hospitals OWNER TO postgres;

--
-- Name: hospitals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hospitals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hospitals_id_seq OWNER TO postgres;

--
-- Name: hospitals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hospitals_id_seq OWNED BY public.hospitals.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_id_seq OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: specialties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specialties (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.specialties OWNER TO postgres;

--
-- Name: specialties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.specialties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specialties_id_seq OWNER TO postgres;

--
-- Name: specialties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.specialties_id_seq OWNED BY public.specialties.id;


--
-- Name: specificlocations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specificlocations (
    id integer NOT NULL,
    name character varying,
    location_id integer
);


ALTER TABLE public.specificlocations OWNER TO postgres;

--
-- Name: specificlocations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.specificlocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specificlocations_id_seq OWNER TO postgres;

--
-- Name: specificlocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.specificlocations_id_seq OWNED BY public.specificlocations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    password character varying,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: payments id; Type: DEFAULT; Schema: doctors; Owner: postgres
--

ALTER TABLE ONLY doctors.payments ALTER COLUMN id SET DEFAULT nextval('doctors.payments_id_seq'::regclass);


--
-- Name: doctors id; Type: DEFAULT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.doctors ALTER COLUMN id SET DEFAULT nextval('hospitals.doctors_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.payments ALTER COLUMN id SET DEFAULT nextval('hospitals.payments_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.services ALTER COLUMN id SET DEFAULT nextval('hospitals.services_id_seq'::regclass);


--
-- Name: specialties id; Type: DEFAULT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.specialties ALTER COLUMN id SET DEFAULT nextval('hospitals.specialties_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.services ALTER COLUMN id SET DEFAULT nextval('locations.services_id_seq'::regclass);


--
-- Name: specialties id; Type: DEFAULT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.specialties ALTER COLUMN id SET DEFAULT nextval('locations.specialties_id_seq'::regclass);


--
-- Name: doctors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors ALTER COLUMN id SET DEFAULT nextval('public.doctors_id_seq'::regclass);


--
-- Name: hospitals id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hospitals ALTER COLUMN id SET DEFAULT nextval('public.hospitals_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: specialties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialties ALTER COLUMN id SET DEFAULT nextval('public.specialties_id_seq'::regclass);


--
-- Name: specificlocations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specificlocations ALTER COLUMN id SET DEFAULT nextval('public.specificlocations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: payments; Type: TABLE DATA; Schema: doctors; Owner: postgres
--

COPY doctors.payments (id, doctor_id, payment_id) FROM stdin;
\.
COPY doctors.payments (id, doctor_id, payment_id) FROM '$$PATH$$/3148.dat';

--
-- Data for Name: doctors; Type: TABLE DATA; Schema: hospitals; Owner: postgres
--

COPY hospitals.doctors (id, hospital_id, doctor_id) FROM stdin;
\.
COPY hospitals.doctors (id, hospital_id, doctor_id) FROM '$$PATH$$/3146.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: hospitals; Owner: postgres
--

COPY hospitals.payments (id, hospital_id, payment_id) FROM stdin;
\.
COPY hospitals.payments (id, hospital_id, payment_id) FROM '$$PATH$$/3140.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: hospitals; Owner: postgres
--

COPY hospitals.services (id, hospital_id, services_id) FROM stdin;
\.
COPY hospitals.services (id, hospital_id, services_id) FROM '$$PATH$$/3142.dat';

--
-- Data for Name: specialties; Type: TABLE DATA; Schema: hospitals; Owner: postgres
--

COPY hospitals.specialties (id, hospital_id, specialty_id) FROM stdin;
\.
COPY hospitals.specialties (id, hospital_id, specialty_id) FROM '$$PATH$$/3144.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: locations; Owner: postgres
--

COPY locations.services (id, services_id, location_id) FROM stdin;
\.
COPY locations.services (id, services_id, location_id) FROM '$$PATH$$/3138.dat';

--
-- Data for Name: specialties; Type: TABLE DATA; Schema: locations; Owner: postgres
--

COPY locations.specialties (id, specialty_id, location_id) FROM stdin;
\.
COPY locations.specialties (id, specialty_id, location_id) FROM '$$PATH$$/3136.dat';

--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctors (id, doc_name, location_id, specialty_id, specialty_name, qualification, consultation_fee, image_url, email, phone_number, rating) FROM stdin;
\.
COPY public.doctors (id, doc_name, location_id, specialty_id, specialty_name, qualification, consultation_fee, image_url, email, phone_number, rating) FROM '$$PATH$$/3128.dat';

--
-- Data for Name: hospitals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hospitals (id, name, operating_hours, address, location_id, specificlocation_id, email, phone_number, rating, image_url) FROM stdin;
\.
COPY public.hospitals (id, name, operating_hours, address, location_id, specificlocation_id, email, phone_number, rating, image_url) FROM '$$PATH$$/3130.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (id, name) FROM stdin;
\.
COPY public.locations (id, name) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, name) FROM stdin;
\.
COPY public.payments (id, name) FROM '$$PATH$$/3134.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name) FROM stdin;
\.
COPY public.services (id, name) FROM '$$PATH$$/3132.dat';

--
-- Data for Name: specialties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specialties (id, name) FROM stdin;
\.
COPY public.specialties (id, name) FROM '$$PATH$$/3126.dat';

--
-- Data for Name: specificlocations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specificlocations (id, name, location_id) FROM stdin;
\.
COPY public.specificlocations (id, name, location_id) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, role, password, createdat, updatedat) FROM stdin;
\.
COPY public.users (id, name, email, role, password, createdat, updatedat) FROM '$$PATH$$/3120.dat';

--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: doctors; Owner: postgres
--

SELECT pg_catalog.setval('doctors.payments_id_seq', 1, false);


--
-- Name: doctors_id_seq; Type: SEQUENCE SET; Schema: hospitals; Owner: postgres
--

SELECT pg_catalog.setval('hospitals.doctors_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: hospitals; Owner: postgres
--

SELECT pg_catalog.setval('hospitals.payments_id_seq', 197, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: hospitals; Owner: postgres
--

SELECT pg_catalog.setval('hospitals.services_id_seq', 30, true);


--
-- Name: specialties_id_seq; Type: SEQUENCE SET; Schema: hospitals; Owner: postgres
--

SELECT pg_catalog.setval('hospitals.specialties_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: locations; Owner: postgres
--

SELECT pg_catalog.setval('locations.services_id_seq', 1, false);


--
-- Name: specialties_id_seq; Type: SEQUENCE SET; Schema: locations; Owner: postgres
--

SELECT pg_catalog.setval('locations.specialties_id_seq', 1, false);


--
-- Name: doctors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doctors_id_seq', 1, false);


--
-- Name: hospitals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hospitals_id_seq', 1, false);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locations_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 59, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 1, false);


--
-- Name: specialties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specialties_id_seq', 1, false);


--
-- Name: specificlocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specificlocations_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: doctors; Owner: postgres
--

ALTER TABLE ONLY doctors.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: specialties specialties_pkey; Type: CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.specialties
    ADD CONSTRAINT specialties_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: specialties specialties_pkey; Type: CONSTRAINT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.specialties
    ADD CONSTRAINT specialties_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: hospitals hospitals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hospitals
    ADD CONSTRAINT hospitals_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: specialties specialties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialties
    ADD CONSTRAINT specialties_pkey PRIMARY KEY (id);


--
-- Name: specificlocations specificlocations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specificlocations
    ADD CONSTRAINT specificlocations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: payments payments_doctor_id_fkey; Type: FK CONSTRAINT; Schema: doctors; Owner: postgres
--

ALTER TABLE ONLY doctors.payments
    ADD CONSTRAINT payments_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: payments payments_payment_id_fkey; Type: FK CONSTRAINT; Schema: doctors; Owner: postgres
--

ALTER TABLE ONLY doctors.payments
    ADD CONSTRAINT payments_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: doctors doctors_doctor_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.doctors
    ADD CONSTRAINT doctors_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: doctors doctors_hospital_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.doctors
    ADD CONSTRAINT doctors_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id);


--
-- Name: payments payments_hospital_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.payments
    ADD CONSTRAINT payments_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id);


--
-- Name: payments payments_payment_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.payments
    ADD CONSTRAINT payments_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: services services_hospital_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.services
    ADD CONSTRAINT services_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id);


--
-- Name: services services_services_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.services
    ADD CONSTRAINT services_services_id_fkey FOREIGN KEY (services_id) REFERENCES public.services(id);


--
-- Name: specialties specialties_hospital_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.specialties
    ADD CONSTRAINT specialties_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id);


--
-- Name: specialties specialties_specialty_id_fkey; Type: FK CONSTRAINT; Schema: hospitals; Owner: postgres
--

ALTER TABLE ONLY hospitals.specialties
    ADD CONSTRAINT specialties_specialty_id_fkey FOREIGN KEY (specialty_id) REFERENCES public.specialties(id);


--
-- Name: services services_location_id_fkey; Type: FK CONSTRAINT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.services
    ADD CONSTRAINT services_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: services services_services_id_fkey; Type: FK CONSTRAINT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.services
    ADD CONSTRAINT services_services_id_fkey FOREIGN KEY (services_id) REFERENCES public.services(id);


--
-- Name: specialties specialties_location_id_fkey; Type: FK CONSTRAINT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.specialties
    ADD CONSTRAINT specialties_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: specialties specialties_specialty_id_fkey; Type: FK CONSTRAINT; Schema: locations; Owner: postgres
--

ALTER TABLE ONLY locations.specialties
    ADD CONSTRAINT specialties_specialty_id_fkey FOREIGN KEY (specialty_id) REFERENCES public.specialties(id);


--
-- Name: doctors doctors_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: doctors doctors_specialty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_specialty_id_fkey FOREIGN KEY (specialty_id) REFERENCES public.specialties(id);


--
-- Name: hospitals hospitals_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hospitals
    ADD CONSTRAINT hospitals_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: hospitals hospitals_specificlocation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hospitals
    ADD CONSTRAINT hospitals_specificlocation_id_fkey FOREIGN KEY (specificlocation_id) REFERENCES public.specificlocations(id);


--
-- Name: specificlocations specificlocations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specificlocations
    ADD CONSTRAINT specificlocations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- PostgreSQL database dump complete
--

